module auto-query-bot

go 1.25.0

require (
	github.com/PuerkitoBio/goquery v1.11.0
	github.com/disintegration/imaging v1.6.2
)

require (
	github.com/andybalholm/cascadia v1.3.3 // indirect
	golang.org/x/image v0.34.0 // indirect
	golang.org/x/net v0.48.0 // indirect
)
