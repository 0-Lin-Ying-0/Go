# External Dependencies

This file lists the dependencies used in this repository.

| Dependency | License |
|-|-|
| Go | BSD 3-Clause "New" or "Revised" License |
| golang.org/x/crypto v0.3.0 | BSD 3-Clause "New" or "Revised" License |
| golang.org/x/net v0.2.0 | BSD 3-Clause "New" or "Revised" License |
| golang.org/x/sys v0.2.0 | BSD 3-Clause "New" or "Revised" License |
| golang.org/x/term v0.2.0 | BSD 3-Clause "New" or "Revised" License |
| golang.org/x/text v0.4.0 | BSD 3-Clause "New" or "Revised" License |
