# SubsidyReturnReceiptStatus

## 枚举


* `RETURN_RECEIPT_UNKNOWN` (value: `"RETURN_RECEIPT_UNKNOWN"`)

* `RETURN_RECEIPT_ACCEPTED` (value: `"RETURN_RECEIPT_ACCEPTED"`)

* `RETURN_RECEIPT_SUCCESS` (value: `"RETURN_RECEIPT_SUCCESS"`)

* `RETURN_RECEIPT_FAIL` (value: `"RETURN_RECEIPT_FAIL"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


