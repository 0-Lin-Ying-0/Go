# ModifyStockSendRule

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**NaturalPersonLimit** | **bool** | true-是；false-否，不填默认否 注：该字段暂不支持修改 | [可选] 
**PreventApiAbuse** | **bool** | true-是；false-否，不填默认否 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


