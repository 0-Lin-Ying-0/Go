# CloseReasonType

* &#x60;MERCHANT_REVOCATION&#x60; - 商户主动撤销, 商户主动撤销（页面方式） * &#x60;OVERDUE_CLOSE&#x60; - 系统超时关闭, 系统超时关闭，可能原因账户余额不足或其他错误 

## 枚举


* `MERCHANT_REVOCATION` (value: `"MERCHANT_REVOCATION"`)

* `OVERDUE_CLOSE` (value: `"OVERDUE_CLOSE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


