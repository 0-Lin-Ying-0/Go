# SplitBillTarType

  * &#x60;GZIP&#x60; - GZIP格式压缩，返回格式为.gzip的压缩包账单

## 枚举


* `GZIP` (value: `"GZIP"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


