# AddActivityMerchantResponse

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**ActivityId** | **string** | 活动Id | [可选] 
**InvalidMerchantIdList** | [**[]InvalidParticipateMerchant**](InvalidParticipateMerchant.md) | 未通过规则校验的发券商户号列表 | [可选] 
**AddTime** | **string** | 成功添加发券商户号的时间 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


