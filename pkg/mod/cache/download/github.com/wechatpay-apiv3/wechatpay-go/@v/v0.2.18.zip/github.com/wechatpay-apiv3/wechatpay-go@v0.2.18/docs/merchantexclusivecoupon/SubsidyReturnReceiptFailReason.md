# SubsidyReturnReceiptFailReason

## 枚举


* `RETURN_RECEIPT_INSUFFICIENT_BALANCE` (value: `"RETURN_RECEIPT_INSUFFICIENT_BALANCE"`)

* `RETURN_RECEIPT_OTHER` (value: `"RETURN_RECEIPT_OTHER"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


