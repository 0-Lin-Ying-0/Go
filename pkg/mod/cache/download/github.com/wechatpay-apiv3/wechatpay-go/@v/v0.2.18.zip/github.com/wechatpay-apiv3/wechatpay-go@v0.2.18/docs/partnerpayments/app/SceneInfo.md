# SceneInfo

支付场景描述

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**PayerClientIp** | **string** | 用户终端IP  | 
**DeviceId** | **string** | 商户端设备号  | [可选] 
**StoreInfo** | [**StoreInfo**](StoreInfo.md) |  | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


