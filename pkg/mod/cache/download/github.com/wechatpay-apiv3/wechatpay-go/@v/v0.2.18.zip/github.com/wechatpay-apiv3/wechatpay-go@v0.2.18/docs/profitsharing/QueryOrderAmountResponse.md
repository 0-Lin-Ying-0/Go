# QueryOrderAmountResponse

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**TransactionId** | **string** | 微信支付订单号 | 
**UnsplitAmount** | **int64** | 订单剩余待分金额，整数，单元为分 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


