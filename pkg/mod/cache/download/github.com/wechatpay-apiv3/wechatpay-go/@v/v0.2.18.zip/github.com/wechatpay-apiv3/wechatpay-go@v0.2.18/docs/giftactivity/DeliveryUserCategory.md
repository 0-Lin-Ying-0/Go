# DeliveryUserCategory

## 枚举


* `DELIVERY_ALL_PERSON` (value: `"DELIVERY_ALL_PERSON"`)

* `DELIVERY_MEMBER_PERSON` (value: `"DELIVERY_MEMBER_PERSON"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


