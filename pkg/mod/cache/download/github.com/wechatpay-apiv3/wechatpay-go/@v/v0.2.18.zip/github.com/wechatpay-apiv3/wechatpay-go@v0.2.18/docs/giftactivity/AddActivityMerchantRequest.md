# AddActivityMerchantRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**ActivityId** | **string** | 活动Id | 
**MerchantIdList** | **[]string** | 新增到活动中的发券商户号列表 | 
**AddRequestNo** | **string** | 商户添加发券商户号的凭据号，商户侧需保持唯一性 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


