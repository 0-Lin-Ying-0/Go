# SetCouponNotifyRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**Mchid** | **string** | 商户号，不填默认查询调用方商户号 | [可选] 
**NotifyUrl** | **string** | 商户提供的用于接收商家券事件通知的URL地址，必须支持HTTPS。 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


