# CodeDisplayMode

## 枚举


* `NOT_SHOW` (value: `"NOT_SHOW"`)

* `BARCODE` (value: `"BARCODE"`)

* `QRCODE` (value: `"QRCODE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


