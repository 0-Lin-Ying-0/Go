---
name: bug-and-feature-request
about: bug或feature request的模版
title: ''
labels: ''
assignees: xy-peng

---

<!--
在这里请只反馈跟微信支付 Go 语言开发库 (wechatpay-go)的 **bug** 或 **feature request**。

如果你在接入微信支付的过程中遇到了业务错误，推荐通过 [腾讯客服自助服务专区](https://kf.qq.com/product/wechatpaymentmerchant.html) 或者 [微信支付在线技术支持](https://support.pay.weixin.qq.com/online-service) 获取帮助，你也可以在微信开放社区的 [开发者专区](https://developers.weixin.qq.com/community/pay) 反馈业务问题。

在反馈问题时，请提供你所使用的 Go 版本和 wechatpay-go 的版本，以及尽可能详细的日志和细节（如调用代码），以便于我们能更快的找到问题。
-->

+ Go 版本：
+ wechatpay-go 版本：
