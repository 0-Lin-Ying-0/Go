# ListActMchResponse

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**Data** | [**[]ActParticipateMchInfo**](ActParticipateMchInfo.md) | 商户信息列表 | [可选] 
**TotalCount** | **int64** | 商户数量 | 
**Offset** | **int64** | 分页页码 | 
**Limit** | **int64** | 分页大小 | 
**ActivityId** | **string** | 活动Id | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


