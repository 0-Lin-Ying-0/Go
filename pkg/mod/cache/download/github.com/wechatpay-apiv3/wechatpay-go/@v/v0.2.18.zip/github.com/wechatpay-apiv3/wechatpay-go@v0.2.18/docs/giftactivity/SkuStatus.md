# SkuStatus

## 枚举


* `SKU_STATUS_INVALID` (value: `"SKU_STATUS_INVALID"`)

* `SKU_STATUS_VAILD` (value: `"SKU_STATUS_VAILD"`)

* `SKU_STATUS_EXPIRE` (value: `"SKU_STATUS_EXPIRE"`)

* `SKU_STATUS_UNKNOWN` (value: `"SKU_STATUS_UNKNOWN"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


