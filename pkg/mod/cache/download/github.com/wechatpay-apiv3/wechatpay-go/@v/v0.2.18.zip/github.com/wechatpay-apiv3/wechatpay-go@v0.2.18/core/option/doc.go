// Copyright 2021 Tencent Inc. All rights reserved.

// Package option 微信支付 API v3 Go SDK Client 初始化参数工具包，你可以使用其中的方法快速构建 core.Client 的初始化参数。
package option
