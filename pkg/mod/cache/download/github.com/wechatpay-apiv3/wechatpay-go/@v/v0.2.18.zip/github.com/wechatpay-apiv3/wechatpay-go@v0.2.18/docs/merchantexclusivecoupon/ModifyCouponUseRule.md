# ModifyCouponUseRule

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**UseMethod** | [**CouponUseMethod**](CouponUseMethod.md) | 核销方式 | [可选] 
**MiniProgramsAppid** | **string** | 核销方式为线上小程序核销才有效 | [可选] 
**MiniProgramsPath** | **string** | 核销方式为线上小程序核销才有效 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


