# UploadCouponCodeFailReason

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**CouponCode** | **string** | 商户通过API上传的券code | 
**Code** | **string** | 对应券code上传失败的错误码 | 
**Message** | **string** | 上传失败的错误信息描述 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


