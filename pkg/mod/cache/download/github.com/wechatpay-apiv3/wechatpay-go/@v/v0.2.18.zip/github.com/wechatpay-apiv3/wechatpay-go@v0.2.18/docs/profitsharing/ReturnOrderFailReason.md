# ReturnOrderFailReason

  * &#x60;ACCOUNT_ABNORMAL&#x60; - 分账接收方账户异常，  * &#x60;BALANCE_NOT_ENOUGH&#x60; - 余额不足，  * &#x60;TIME_OUT_CLOSED&#x60; - 超时关单，

## 枚举


* `ACCOUNT_ABNORMAL` (value: `"ACCOUNT_ABNORMAL"`)

* `BALANCE_NOT_ENOUGH` (value: `"BALANCE_NOT_ENOUGH"`)

* `TIME_OUT_CLOSED` (value: `"TIME_OUT_CLOSED"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


