# ThresholdCategory

## 枚举


* `AMOUNT_THRESHOLD` (value: `"AMOUNT_THRESHOLD"`)

* `NUMBER_THRESHOLD` (value: `"NUMBER_THRESHOLD"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


