# TransferScene

* &#x60;ORDINARY_TRANSFER&#x60; - 普通转账, 普通转账（默认） * &#x60;PAYROLL_CARD_TRANSFER&#x60; - 薪工卡转账, 给使用微信薪工卡的用户进行转账 

## 枚举


* `ORDINARY_TRANSFER` (value: `"ORDINARY_TRANSFER"`)

* `PAYROLL_CARD_TRANSFER` (value: `"PAYROLL_CARD_TRANSFER"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


