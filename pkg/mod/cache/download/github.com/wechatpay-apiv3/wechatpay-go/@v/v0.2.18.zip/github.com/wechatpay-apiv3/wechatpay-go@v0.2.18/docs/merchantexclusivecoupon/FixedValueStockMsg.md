# FixedValueStockMsg

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**DiscountAmount** | **int64** | 优惠金额 单位分。 特殊规则：取值范围 1 ≤ value ≤ 10000000 | [可选] 
**TransactionMinimum** | **int64** | 消费门槛，单位：分。 特殊规则：取值范围 1 ≤ value ≤ 10000000 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


