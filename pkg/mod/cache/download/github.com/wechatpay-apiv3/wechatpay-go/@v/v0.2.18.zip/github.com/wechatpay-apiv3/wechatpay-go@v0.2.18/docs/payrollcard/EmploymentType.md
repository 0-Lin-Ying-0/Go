# EmploymentType

## 枚举


* `LONG_TERM_EMPLOYMENT` (value: `"LONG_TERM_EMPLOYMENT"`)

* `SHORT_TERM_EMPLOYMENT` (value: `"SHORT_TERM_EMPLOYMENT"`)

* `COOPERATION_EMPLOYMENT` (value: `"COOPERATION_EMPLOYMENT"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


