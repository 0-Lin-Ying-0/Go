# PaymentMethodInfo

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**PaymentMethod** | [**PaymentMethodCategory**](PaymentMethodCategory.md) | 支付方式，可以指定银行卡或零钱 | 
**BankAbbreviation** | **string** | 银行简称，指定支付方式为银行卡必填，详询附录 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


