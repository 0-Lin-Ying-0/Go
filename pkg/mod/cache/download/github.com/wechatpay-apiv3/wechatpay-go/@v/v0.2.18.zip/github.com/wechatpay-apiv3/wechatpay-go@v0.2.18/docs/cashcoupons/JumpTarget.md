# JumpTarget

## 枚举


* `PAYMENT_CODE` (value: `"PAYMENT_CODE"`)

* `MINI_PROGRAM` (value: `"MINI_PROGRAM"`)

* `DEFAULT_PAGE` (value: `"DEFAULT_PAGE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


