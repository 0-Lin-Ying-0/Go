# AvailableWeek

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**WeekDay** | **[]int64** | 0代表周日，1代表周一，以此类推 当填写available_day_time时，week_day必填 | [可选] 
**AvailableDayTime** | [**[]AvailableCurrentDayTime**](AvailableCurrentDayTime.md) | 可以填写多个时间段，最多不超过2个 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


