# FixedValueStockMsg

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**CouponAmount** | **int64** | 面额，单位分 | 
**TransactionMinimum** | **int64** | 使用券金额门槛，单位分 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


