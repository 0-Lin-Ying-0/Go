# CouponCodeMode

## 枚举


* `WECHATPAY_MODE` (value: `"WECHATPAY_MODE"`)

* `MERCHANT_API` (value: `"MERCHANT_API"`)

* `MERCHANT_UPLOAD` (value: `"MERCHANT_UPLOAD"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


