# TransferUseType

* &#x60;GOODSPAYMENT&#x60; - 货款,  给用户支付货物采购资金 * &#x60;COMMISSION&#x60; - 佣金, 给用户支付业务推广佣金 * &#x60;REFUND&#x60; - 退款, 给用户支付交易退款 * &#x60;REIMBURSEMENT&#x60; - 报销, 企业给员工支付差旅等报销资金 * &#x60;FREIGHT&#x60; - 运费, 给司机支付运输费用 * &#x60;OTHERS&#x60; - 其他, 其他 

## 枚举


* `GOODSPAYMENT` (value: `"GOODSPAYMENT"`)

* `COMMISSION` (value: `"COMMISSION"`)

* `REFUND` (value: `"REFUND"`)

* `REIMBURSEMENT` (value: `"REIMBURSEMENT"`)

* `FREIGHT` (value: `"FREIGHT"`)

* `OTHERS` (value: `"OTHERS"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


