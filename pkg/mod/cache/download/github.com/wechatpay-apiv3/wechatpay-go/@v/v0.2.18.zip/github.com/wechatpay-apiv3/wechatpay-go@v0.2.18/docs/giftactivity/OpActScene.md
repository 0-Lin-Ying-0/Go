# OpActScene

## 枚举


* `OP_ACT_SCENE_JONIT_PLAN_CREATOR` (value: `"OP_ACT_SCENE_JONIT_PLAN_CREATOR"`)

* `OP_ACT_SCENE_JONIT_PLAN_AUTHORIZED_MCH` (value: `"OP_ACT_SCENE_JONIT_PLAN_AUTHORIZED_MCH"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


