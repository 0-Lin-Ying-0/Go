# ModifyMiniAppInfo

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**MiniProgramsAppid** | **string** | 需要小程序AppID与归属商户号有绑定关系 | [可选] 
**MiniProgramsPath** | **string** | 商家小程序path | [可选] 
**EntranceWords** | **string** | 入口文案，字数上限为5个，一个中文汉字/英文字母/数字均占用一个字数。 | [可选] 
**GuidingWords** | **string** | 小程序入口引导文案，字数上限为6个，一个中文汉字/英文字母/数字均占用一个字数。 | [可选] 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


