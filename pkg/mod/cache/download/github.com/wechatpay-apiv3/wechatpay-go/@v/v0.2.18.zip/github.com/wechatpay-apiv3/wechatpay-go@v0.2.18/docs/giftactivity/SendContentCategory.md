# SendContentCategory

## 枚举


* `SINGLE_COUPON` (value: `"SINGLE_COUPON"`)

* `GIFT_PACKAGE` (value: `"GIFT_PACKAGE"`)


[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


