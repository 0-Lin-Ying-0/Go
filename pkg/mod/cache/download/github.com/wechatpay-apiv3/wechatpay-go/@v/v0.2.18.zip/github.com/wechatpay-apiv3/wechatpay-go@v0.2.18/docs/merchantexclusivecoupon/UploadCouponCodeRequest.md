# UploadCouponCodeRequest

## 属性列表

名称 | 类型 | 描述 | 补充说明
------------ | ------------- | ------------- | -------------
**StockId** | **string** | 商家券批次号 | 
**CouponCodeList** | **[]string** | 商户上传的券code列表；code允许包含的字符有 0-9 a-z A-Z 空格（仅含空格，不含制表符、换行符、换页符等） 中划线- 下划线_  反斜线\\ 斜线/ 等号&#x3D; 竖线|  | 
**UploadRequestNo** | **string** | 商户上传code的凭据号，商户侧需保持唯一性 | 

[\[返回类型列表\]](README.md#类型列表)
[\[返回接口列表\]](README.md#接口列表)
[\[返回服务README\]](README.md)


