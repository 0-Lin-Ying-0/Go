package search

type GeoPoint struct {
	Lat float64 //[-90, 90]
	Lon float64 //[-180, 180]
}
