# toxiproxy

A minimal client implementation to setup proxies and toxics in toxiproxy as used in the FV suite.
We have our own minimal client implementation to avoid having to pull in the toxiproxy repo which carries a number of transitive dependencies.
