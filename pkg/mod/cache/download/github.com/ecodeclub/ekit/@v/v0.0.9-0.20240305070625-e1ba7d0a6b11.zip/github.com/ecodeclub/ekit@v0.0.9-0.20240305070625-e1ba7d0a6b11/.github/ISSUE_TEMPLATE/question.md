---
name: Question
about: Want to ask some questions
title: ''
labels: question
---

**仅限中文**

在提之前请先查找[已有 issues](https://github.com/ecodeclub/eorm/issues)，避免重复上报。

并且确保自己已经：
- [ ] 阅读过文档
- [ ] 阅读过注释
- [ ] 阅读过例子

### 你的问题

### 你使用的是 ekit 哪个版本?

### 你设置的的 Go 环境?
> 上传 `go env` 的结果
