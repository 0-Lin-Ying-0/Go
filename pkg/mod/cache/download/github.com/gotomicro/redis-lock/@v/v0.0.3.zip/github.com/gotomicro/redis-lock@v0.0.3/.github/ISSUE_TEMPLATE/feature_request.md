---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: feature
assignees: ''

---

**仅限中文**

### 使用场景

### 行业分析
> 如果你知道有框架提供了类似功能，可以在这里描述，并且给出文档或者例子

### 可行方案
> 如果你有设计思路或者解决方案，请在这里提供。你可以提供多个方案，并且给出自己的选择

### 其它
> 任何你觉得有利于解决问题的补充说明

### 你使用的是 redis-lock 哪个版本?

### 你设置的的 Go 环境?
> 上传 `go env` 的结果
