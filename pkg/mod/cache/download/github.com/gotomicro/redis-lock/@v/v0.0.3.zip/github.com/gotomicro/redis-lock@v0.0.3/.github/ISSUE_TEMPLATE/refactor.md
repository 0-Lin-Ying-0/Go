---
name: Refactor request
about: Refactor existing code
title: ''
labels: refactor
assignees: ''

---

**仅限中文**

### 当前实现缺陷

### 重构方案
> 描述可以如何重构，以及重构之后带来的效果，如可读性、性能等方面的提升

### 其它
> 任何你觉得有利于解决问题的补充说明

### 你使用的是 redis-lock 哪个版本?

### 你设置的的 Go 环境?
> 上传 `go env` 的结果
