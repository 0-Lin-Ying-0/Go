---
name: 问题 | Question
about: 你想问的问题 | The question you want to ask
title: ''
labels: ["question"]
---

在提交之前请先查找 [已有 issues](https://github.com/chenmingyong0423/go-mongox/issues)，避免重复上报。| Before submitting, please search for [existing issues](https://github.com/chenmingyong0423/go-mongox/issues) to avoid duplicate reports.

### 您使用的 mongox 版本 | The version of mongox you are using

### 你的问题 | Your question

### 你设置的的 Go 环境 | Your Go Environment Setting
> 上传 `go env` 的结果 | Upload the result of `go env`
