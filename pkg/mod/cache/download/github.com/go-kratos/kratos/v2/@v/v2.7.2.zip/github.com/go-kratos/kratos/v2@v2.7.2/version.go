package kratos

// Release is the current kratos version.
const Release = "v2.7.2"
